# AI Mutual Fund Advisor — Dashboard

React + Vite frontend replicating the dashboard UI.

## Setup

```bash
npm install
npm run dev
```

Then open the printed local URL (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Structure

- `src/App.jsx` — page layout, composes all sections
- `src/components/Sidebar.jsx` — left navigation + upgrade card
- `src/components/Header.jsx` — search bar + profile
- `src/components/WelcomeBanner.jsx` — greeting + date pill
- `src/components/StatsRow.jsx` — 4 top metric cards (Portfolio Value, AI Score, Total Invested, Risk Profile)
- `src/components/PortfolioChart.jsx` — area chart (recharts) with 1M/3M/6M/1Y/All toggle
- `src/components/AiRecommendations.jsx` — AI Top Recommendations list
- `src/components/AssetAllocation.jsx` — donut chart (recharts) + legend
- `src/components/RecentInvestments.jsx` — recent transactions list
- `src/components/MarketOverview.jsx` — NIFTY/SENSEX/Bank index cards
- `src/components/NewsInsights.jsx` — news card grid

All data is static/mock — wire it up to your real API by replacing the arrays at
the top of each component file.

Dependencies: `react`, `react-dom`, `recharts`.
