import './AiRecommendations.css'

const funds = [
  {
    name: 'Parag Parikh Flexi Cap Fund',
    tag: 'Equity • Flexi Cap',
    score: 92,
    logo: 'P',
    color: '#ffffff',
    bg: '#ffffff',
    textColor: '#1b1e2a',
  },
  {
    name: 'SBI Small Cap Fund',
    tag: 'Equity • Small Cap',
    score: 88,
    logo: '🔵',
    bg: '#0b3d91',
  },
  {
    name: 'HDFC Balanced Advantage Fund',
    tag: 'Hybrid • Dynamic Asset Allocation',
    score: 85,
    logo: '🔴',
    bg: '#c0392b',
  },
]

export default function AiRecommendations() {
  return (
    <section className="panel reco-panel">
      <div className="panel-header">
        <span className="panel-title">AI Top Recommendations</span>
        <a className="view-all" href="#">View All</a>
      </div>

      <div className="reco-list">
        {funds.map((f) => (
          <div className="reco-item" key={f.name}>
            <div className="reco-logo" style={{ background: f.bg }}>
              {f.logo}
            </div>
            <div className="reco-info">
              <div className="reco-name">{f.name}</div>
              <div className="reco-tag">{f.tag}</div>
            </div>
            <div className="reco-score">
              <div className="reco-score-label">AI Score</div>
              <div className="reco-score-value">{f.score}</div>
            </div>
            <button className="reco-view-btn">View</button>
          </div>
        ))}
      </div>
    </section>
  )
}
