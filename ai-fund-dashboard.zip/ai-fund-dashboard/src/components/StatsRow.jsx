import './StatsRow.css'

const sparkPoints =
  '0,28 10,24 20,26 30,18 40,20 50,12 60,16 70,8 80,10 90,4 100,0'

export default function StatsRow() {
  return (
    <div className="stats-row">
      <div className="stat-card panel">
        <div className="stat-top">
          <span className="stat-label">Portfolio Value</span>
          <span className="stat-icon stat-icon--purple">💼</span>
        </div>
        <div className="stat-value">₹2,45,678</div>
        <div className="stat-change stat-change--up">
          + ₹15,340 (6.65%)
        </div>
        <div className="stat-sub">All Time Return</div>
        <svg className="sparkline" viewBox="0 0 100 28" preserveAspectRatio="none">
          <polyline points={sparkPoints} fill="none" stroke="var(--accent-purple)" strokeWidth="2" />
        </svg>
      </div>

      <div className="stat-card panel">
        <div className="stat-top">
          <span className="stat-label">AI Portfolio Score</span>
          <span className="stat-icon stat-icon--green">📈</span>
        </div>
        <div className="score-row">
          <div>
            <div className="stat-value stat-value--inline">
              85 <span className="score-tag">Very Good</span>
            </div>
            <div className="stat-sub">
              This score is calculated using 15+ financial parameters
            </div>
          </div>
          <div className="score-ring">
            <svg viewBox="0 0 80 80">
              <circle cx="40" cy="40" r="34" className="ring-bg" />
              <circle
                cx="40"
                cy="40"
                r="34"
                className="ring-fg"
                strokeDasharray={`${(85 / 100) * 213.6} 213.6`}
              />
            </svg>
            <span className="ring-value">85</span>
          </div>
        </div>
      </div>

      <div className="stat-card panel">
        <div className="stat-top">
          <span className="stat-label">Total Invested</span>
          <span className="stat-icon stat-icon--blue">🗄️</span>
        </div>
        <div className="stat-value">₹2,00,000</div>
        <div className="stat-sub">Current Return</div>
        <div className="stat-change stat-change--up">+ ₹45,678 (22.84%)</div>
      </div>

      <div className="stat-card panel">
        <div className="stat-top">
          <span className="stat-label">Risk Profile</span>
          <span className="stat-icon stat-icon--orange">🛡️</span>
        </div>
        <div className="stat-value stat-value--orange">Moderate</div>
        <div className="stat-sub">
          Your portfolio is balanced and suitable for long term growth.
        </div>
      </div>
    </div>
  )
}
