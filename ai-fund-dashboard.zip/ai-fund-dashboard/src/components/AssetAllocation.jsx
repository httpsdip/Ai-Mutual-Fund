import { PieChart, Pie, Cell } from 'recharts'
import './AssetAllocation.css'

const data = [
  { name: 'Equity', value: 65, color: '#7c6bf0' },
  { name: 'Hybrid', value: 20, color: '#3aa0e8' },
  { name: 'Debt', value: 10, color: '#2ecc8f' },
  { name: 'Gold', value: 5, color: '#e8963a' },
]

export default function AssetAllocation() {
  return (
    <section className="panel allocation-panel">
      <div className="panel-header">
        <span className="panel-title">Asset Allocation</span>
      </div>

      <div className="allocation-body">
        <div className="donut-wrap">
          <PieChart width={150} height={150}>
            <Pie
              data={data}
              dataKey="value"
              innerRadius={48}
              outerRadius={70}
              paddingAngle={2}
              stroke="none"
            >
              {data.map((d) => (
                <Cell key={d.name} fill={d.color} />
              ))}
            </Pie>
          </PieChart>
          <div className="donut-center">
            <div className="donut-value">₹2,45,678</div>
            <div className="donut-label">Total Value</div>
          </div>
        </div>

        <div className="allocation-legend">
          {data.map((d) => (
            <div className="legend-row" key={d.name}>
              <span className="legend-dot" style={{ background: d.color }} />
              <span className="legend-name">{d.name}</span>
              <span className="legend-value">{d.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
