import { useState } from 'react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts'
import './PortfolioChart.css'

const data = [
  { month: 'Dec 24', value: 200000 },
  { month: '', value: 205000 },
  { month: 'Jan 25', value: 198000 },
  { month: '', value: 212000 },
  { month: 'Feb 25', value: 220000 },
  { month: '', value: 215000 },
  { month: 'Mar 25', value: 232000 },
  { month: '', value: 228000 },
  { month: 'Apr 25', value: 238000 },
  { month: '', value: 242000 },
  { month: 'May 25', value: 245678 },
]

const ranges = ['1M', '3M', '6M', '1Y', 'All']

export default function PortfolioChart() {
  const [range, setRange] = useState('6M')

  return (
    <section className="panel chart-panel">
      <div className="chart-header">
        <span className="panel-title">Portfolio Performance</span>
        <div className="range-toggle">
          {ranges.map((r) => (
            <button
              key={r}
              className={`range-btn ${range === r ? 'range-btn--active' : ''}`}
              onClick={() => setRange(r)}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="chart-body">
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
            <defs>
              <linearGradient id="portfolioFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#7c6bf0" stopOpacity={0.45} />
                <stop offset="100%" stopColor="#7c6bf0" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid vertical={false} stroke="#ffffff0a" />
            <XAxis
              dataKey="month"
              tick={{ fill: '#6b7086', fontSize: 12 }}
              axisLine={{ stroke: '#ffffff14' }}
              tickLine={false}
              interval={0}
            />
            <YAxis
              tickFormatter={(v) => `₹${v / 100000}L`}
              tick={{ fill: '#6b7086', fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              domain={['dataMin - 20000', 'dataMax + 20000']}
            />
            <Tooltip
              contentStyle={{
                background: '#1b1e2a',
                border: '1px solid #2a2e3d',
                borderRadius: 10,
                fontSize: 12,
                color: '#f5f6fa',
              }}
              formatter={(value) => [`₹${value.toLocaleString('en-IN')}`, 'Value']}
              labelFormatter={() => ''}
            />
            <Area
              type="monotone"
              dataKey="value"
              stroke="#8b7bf5"
              strokeWidth={2.5}
              fill="url(#portfolioFill)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </section>
  )
}
