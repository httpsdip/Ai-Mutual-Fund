import './WelcomeBanner.css'

export default function WelcomeBanner() {
  return (
    <div className="welcome-row">
      <div>
        <h1 className="welcome-title">Welcome back, Joydip! 👋</h1>
        <p className="welcome-sub">
          Here&apos;s what&apos;s happening with your investments today.
        </p>
      </div>
      <button className="date-pill">📅 May 22, 2025</button>
    </div>
  )
}
