import './Header.css'

export default function Header() {
  return (
    <header className="topbar">
      <div className="search-bar">
        <span className="search-icon">🔍</span>
        <input
          type="text"
          placeholder="Search mutual funds, categories or keywords..."
        />
      </div>

      <div className="topbar-actions">
        <button className="icon-btn" aria-label="Notifications">
          🔔
          <span className="notif-badge">3</span>
        </button>

        <div className="profile">
          <img
            className="avatar"
            src="https://i.pravatar.cc/64?img=13"
            alt="Joydip Dey"
          />
          <div className="profile-info">
            <div className="profile-name">Joydip Dey</div>
            <div className="profile-plan">Premium Plan</div>
          </div>
          <span className="chevron">⌄</span>
        </div>
      </div>
    </header>
  )
}
