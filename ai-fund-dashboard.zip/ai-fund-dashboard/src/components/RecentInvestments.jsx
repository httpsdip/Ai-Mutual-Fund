import './RecentInvestments.css'

const investments = [
  {
    name: 'Parag Parikh Flexi Cap Fund',
    meta: 'SIP • ₹5,000',
    date: '22 May 2025',
    status: 'Success',
    logo: 'P',
    bg: '#ffffff',
  },
  {
    name: 'SBI Small Cap Fund',
    meta: 'Lumpsum • ₹20,000',
    date: '20 May 2025',
    status: 'Success',
    logo: '🔵',
    bg: '#0b3d91',
  },
  {
    name: 'HDFC Balanced Advantage Fund',
    meta: 'SIP • ₹5,000',
    date: '18 May 2025',
    status: 'Success',
    logo: '🔴',
    bg: '#c0392b',
  },
]

export default function RecentInvestments() {
  return (
    <section className="panel investments-panel">
      <div className="panel-header">
        <span className="panel-title">Recent Investments</span>
        <a className="view-all" href="#">View All</a>
      </div>

      <div className="investments-list">
        {investments.map((inv) => (
          <div className="investment-item" key={inv.name}>
            <div className="investment-logo" style={{ background: inv.bg }}>
              {inv.logo}
            </div>
            <div className="investment-info">
              <div className="investment-name">{inv.name}</div>
              <div className="investment-meta">{inv.meta}</div>
            </div>
            <div className="investment-status">
              <div className="investment-date">{inv.date}</div>
              <div className="investment-success">{inv.status}</div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
