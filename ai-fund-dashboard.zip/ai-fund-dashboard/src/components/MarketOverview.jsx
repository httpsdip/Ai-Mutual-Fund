import './MarketOverview.css'

const markets = [
  { name: 'NIFTY 50', value: '24,857.30', change: '+0.85%', icon: '🔷' },
  { name: 'SENSEX', value: '81,721.08', change: '+0.92%', icon: '🔶' },
  { name: 'NIFTY Bank', value: '55,341.45', change: '+1.12%', icon: '🏦' },
]

const points = '0,18 10,15 20,16 30,10 40,12 50,6 60,8 70,3 80,5 90,0'

export default function MarketOverview() {
  return (
    <section className="panel market-panel">
      <div className="panel-header">
        <span className="panel-title">Market Overview</span>
        <a className="view-all" href="#">View All</a>
      </div>

      <div className="market-list">
        {markets.map((m) => (
          <div className="market-item" key={m.name}>
            <div className="market-left">
              <span className="market-icon">{m.icon}</span>
              <div>
                <div className="market-name">{m.name}</div>
                <div className="market-value">{m.value}</div>
              </div>
            </div>
            <div className="market-right">
              <div className="market-change">{m.change}</div>
              <svg className="market-spark" viewBox="0 0 90 18" preserveAspectRatio="none">
                <polyline points={points} fill="none" stroke="var(--accent-green)" strokeWidth="2" />
              </svg>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
