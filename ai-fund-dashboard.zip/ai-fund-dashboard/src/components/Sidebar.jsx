import './Sidebar.css'

const navItems = [
  { label: 'Dashboard', icon: '🏠', active: true },
  { label: 'Search Funds', icon: '🔍' },
  { label: 'AI Recommendation', icon: '🧠' },
  { label: 'Compare Funds', icon: '📊' },
  { label: 'Portfolio', icon: '💼' },
  { label: 'Watchlist', icon: '⭐' },
  { label: 'SIP Calculator', icon: '📅' },
  { label: 'News & Insights', icon: '📰' },
  { label: 'Reports', icon: '📄' },
  { label: 'Chat with AI', icon: '💬' },
  { label: 'Settings', icon: '⚙️' },
]

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">
        <div className="brand-mark">📈</div>
        <div>
          <div className="brand-title">AI Mutual Fund Advisor</div>
          <div className="brand-subtitle">Smart Investment, Better Future</div>
        </div>
      </div>

      <nav className="sidebar-nav">
        {navItems.map((item) => (
          <button
            key={item.label}
            className={`nav-item ${item.active ? 'nav-item--active' : ''}`}
          >
            <span className="nav-icon">{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="upgrade-card">
        <div className="upgrade-icon">💎</div>
        <div className="upgrade-title">Upgrade to Premium</div>
        <div className="upgrade-desc">
          Unlock advanced AI insights, portfolio analysis &amp; more.
        </div>
        <button className="upgrade-btn">Upgrade Now</button>
      </div>

      <button className="collapse-btn" aria-label="Collapse sidebar">
        «
      </button>
    </aside>
  )
}
