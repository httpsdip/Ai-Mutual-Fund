import './NewsInsights.css'

const news = [
  {
    title: 'RBI keeps repo rate unchanged at 6.50% for the 8th consecutive time',
    date: '22 May 2025',
    img: 'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?w=300&h=200&fit=crop',
  },
  {
    title: 'Markets rally as inflation cools down, boosting investor sentiment',
    date: '22 May 2025',
    img: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=300&h=200&fit=crop',
  },
  {
    title: 'FIIs turn net buyers in May, inflows cross ₹15,000 crore',
    date: '21 May 2025',
    img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=300&h=200&fit=crop',
  },
  {
    title: 'IT & Banking stocks lead the surge in Indian markets',
    date: '21 May 2025',
    img: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=300&h=200&fit=crop',
  },
]

export default function NewsInsights() {
  return (
    <section className="panel news-panel">
      <div className="panel-header">
        <span className="panel-title">Latest News &amp; Insights</span>
        <a className="view-all" href="#">View All</a>
      </div>

      <div className="news-grid">
        {news.map((n) => (
          <div className="news-card" key={n.title}>
            <img className="news-img" src={n.img} alt="" />
            <div className="news-title">{n.title}</div>
            <div className="news-date">{n.date}</div>
          </div>
        ))}
      </div>
    </section>
  )
}
