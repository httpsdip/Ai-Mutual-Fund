import Sidebar from './components/Sidebar'
import Header from './components/Header'
import WelcomeBanner from './components/WelcomeBanner'
import StatsRow from './components/StatsRow'
import PortfolioChart from './components/PortfolioChart'
import AiRecommendations from './components/AiRecommendations'
import AssetAllocation from './components/AssetAllocation'
import RecentInvestments from './components/RecentInvestments'
import MarketOverview from './components/MarketOverview'
import NewsInsights from './components/NewsInsights'
import './App.css'

export default function App() {
  return (
    <div className="app-shell">
      <Sidebar />

      <main className="main-area">
        <Header />
        <WelcomeBanner />
        <StatsRow />

        <div className="content-grid">
          <PortfolioChart />
          <AiRecommendations />
        </div>

        <div className="content-grid content-grid--triple">
          <AssetAllocation />
          <RecentInvestments />
          <MarketOverview />
        </div>

        <NewsInsights />
      </main>
    </div>
  )
}
